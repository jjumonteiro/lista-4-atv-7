#include <iostream>

using namespace std;

main(){

setlocale( LC_ALL, "portuguese");

float numero;

	cout << "Escolha um numero entre 1 e 7:" << endl <<"dia 01=segunda" << endl;
	cin >> numero;

if (numero <5) {
	cout << "Dia �til";
		
} else if (numero= 6 or 7){
	cout << "Fim de semana";
		
} 
}

